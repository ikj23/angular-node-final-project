import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface OrderProduct {
  id: number;
  name: string;
  price: number;
  imagePath: string | null;
}

export interface OrderItem {
  id: number;
  quantity: number;
  priceAtPurchase: number;
  product: OrderProduct;
}

export interface Order {
  id: number;
  totalAmount: number;
  paymentMethod: string;
  createdAt: string;
  items: OrderItem[];
}

export interface CheckoutResponse {
  message: string;
  order: {
    id: number;
    totalAmount: number;
    paymentMethod: string;
    createdAt: string;
  };
}

@Injectable({
  providedIn: 'root'
})
export class OrderService {
  private apiUrl = '/api/orders';

  constructor(private http: HttpClient) { }

  checkout(paymentMethod: string): Observable<CheckoutResponse> {
    return this.http.post<CheckoutResponse>(
      `${this.apiUrl}/checkout`,
      { paymentMethod },
      { withCredentials: true }
    );
  }

  getMyOrders(): Observable<Order[]> {
    return this.http.get<Order[]>(this.apiUrl, { withCredentials: true });
  }

  getOrderById(id: number): Observable<Order> {
    return this.http.get<Order>(`${this.apiUrl}/${id}`, { withCredentials: true });
  }
}