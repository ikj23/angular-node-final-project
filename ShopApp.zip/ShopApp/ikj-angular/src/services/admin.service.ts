// src/app/services/admin.service.ts
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Customer {
  id: number;
  name: string;
  email: string;
  isLocked: boolean;
}

export interface AdminOrderItem {
  id: number;
  quantity: number;
  priceAtPurchase: number;
  product: {
    id: number;
    name: string;
  };
}

export interface AdminOrder {
  id: number;
  totalAmount: number;
  paymentMethod: string;
  createdAt: string;
  customer: {
    id: number;
    name: string;
    email: string;
  };
  items: AdminOrderItem[];
}

@Injectable({ providedIn: 'root' })
export class AdminService {
  private apiUrl = '/api/admin';

  constructor(private http: HttpClient) { }

  getAllCustomers(): Observable<Customer[]> {
    return this.http.get<Customer[]>(`${this.apiUrl}/customers`, { withCredentials: true });
  }

  toggleCustomerLock(id: number, isLocked: boolean): Observable<any> {
    return this.http.put(`${this.apiUrl}/customers/${id}/lock`, { isLocked }, { withCredentials: true });
  }

  getAllOrders(): Observable<AdminOrder[]> {
    return this.http.get<AdminOrder[]>(`${this.apiUrl}/orders`, { withCredentials: true });
  }

  getOrderById(id: number): Observable<AdminOrder> {
    return this.http.get<AdminOrder>(`${this.apiUrl}/orders/${id}`, { withCredentials: true });
  }
}