import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, tap } from 'rxjs';

export interface User {
  id: number,
  name: string,
  email: string,
  role: string
}

@Injectable({
  providedIn: 'root'
})
export class AuthService {


  private apiUrl = '/api/auth';
  private currentUserSubject = new BehaviorSubject<User | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor(private http: HttpClient) { }

  register(data: { name: string, email: string, password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/register`, data, { withCredentials: true });
  }

  login(data: { email: string; password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/login`, data, { withCredentials: true }).pipe(
      tap(() => this.fetchAndSetUser())
    );
  }

  logout(): Observable<any> {
    return this.http.post(`${this.apiUrl}/logout`, {}, { withCredentials: true }).pipe(
      tap(() => this.currentUserSubject.next(null))
    );
  }

  currentUser(): Observable<User> {
    return this.http.get<User>(`${this.apiUrl}/me`, { withCredentials: true });
  }

  fetchAndSetUser() {
    this.currentUser().subscribe({
      next: (user) => this.currentUserSubject.next(user),
      error: () => this.currentUserSubject.next(null)
    });
  }

  forgotPassword(data: { email: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/forgot-password`, data, { withCredentials: true })
  }

  resetPassword(data: { email: string, code: number, password: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/reset-password`, data, { withCredentials: true })
  }

  ChangePassword(data: { currentpassword: string, newpassword: string }): Observable<any> {
    return this.http.post(`${this.apiUrl}/change-password`, data, { withCredentials: true })
  }

  updateProfile(data: { name: string; email: string }): Observable<any> {
    return this.http.put(`${this.apiUrl}/profile`, data, { withCredentials: true });
  }
}
