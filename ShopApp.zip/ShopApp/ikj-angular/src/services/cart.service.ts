import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface CartProduct {
  id: number;
  name: string;
  price: number;
  imagePath: string | null;
}

export interface CartItem {
  id: number;
  quantity: number;
  product: CartProduct;
}

export interface Cart {
  cartId: number;
  items: CartItem[];
  total: number;
}

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private apiUrl = '/api/cart';

  constructor(private http: HttpClient) { }

  getCart(): Observable<Cart> {
    return this.http.get<Cart>(this.apiUrl, { withCredentials: true });
  }

  addToCart(productId: number, quantity: number = 1): Observable<{ message: string }> {
    return this.http.post<{ message: string }>(`${this.apiUrl}/items`, {
      productId,
      quantity
    }, { withCredentials: true });
  }

  updateCartItem(itemId: number, quantity: number): Observable<{ message: string }> {
    return this.http.put<{ message: string }>(`${this.apiUrl}/items/${itemId}`, {
      quantity
    }, { withCredentials: true });
  }

  removeCartItem(itemId: number): Observable<{ message: string }> {
    return this.http.delete<{ message: string }>(`${this.apiUrl}/items/${itemId}`, { withCredentials: true });
  }
}