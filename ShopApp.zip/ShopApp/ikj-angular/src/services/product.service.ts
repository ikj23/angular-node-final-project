import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map, Observable } from 'rxjs';

export interface ProductType {
  id: number;
  name: string;
}

export interface Category {
  id: number;
  name: string;
  type: ProductType;
}

export interface SubCategory {
  id: number;
  name: string;
  category: Category;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  stock: number;
  imagePath: string | null;
  subCategory: SubCategory;
}

export interface ProductsResponse {
  products: Product[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}


@Injectable({
  providedIn: 'root'
})
export class ProductService {

  private apiUrl = '/api/products';

  constructor(private http: HttpClient) {}

  getAllProduct(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

   getFilteredProducts(
    search?: string,
    typeId?: number,
    categoryId?: number,
    subCategoryId?: number,
    page: number = 1,      // NEW
    limit: number = 6      // NEW
  ): Observable<ProductsResponse> {
    let url = this.apiUrl + '?';
    if (search) url += `search=${search}&`;
    if (typeId) url += `typeId=${typeId}&`;
    if (categoryId) url += `categoryId=${categoryId}&`;
    if (subCategoryId) url += `subCategoryId=${subCategoryId}&`;
    url += `page=${page}&limit=${limit}`; 

    return this.http.get<ProductsResponse>(url);
  }

  getProductById(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }

  createProduct(formData: FormData): Observable<any> {
    return this.http.post(this.apiUrl, formData, { withCredentials: true });
  }

  updateProduct(id: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, formData, { withCredentials: true });
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`, { withCredentials: true });
  }

  getTypes(): Observable<ProductType[]> {
    return this.http.get<ProductType[]>(`${this.apiUrl}/taxonomy/types`);
  }

  getCategories(typeId?: number): Observable<Category[]> {
    const url = typeId
      ? `${this.apiUrl}/taxonomy/categories?typeId=${typeId}`
      : `${this.apiUrl}/taxonomy/categories`;
    return this.http.get<Category[]>(url);
  }

  getSubCategories(categoryId?: number): Observable<SubCategory[]> {
    const url = categoryId
      ? `${this.apiUrl}/taxonomy/subcategories?categoryId=${categoryId}`
      : `${this.apiUrl}/taxonomy/subcategories`;
    return this.http.get<SubCategory[]>(url);
  }

  getAllProductsAdmin(): Observable<Product[]> {
    // fetch with a very high limit so all products come back
    return this.http.get<any>(`${this.apiUrl}?page=1&limit=10000`).pipe(
        map((res: any) => res.products)
    );
}
}