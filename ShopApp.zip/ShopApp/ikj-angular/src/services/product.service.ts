import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface ProductType {
  id: number;
  name: string;
}

export interface Category {
  id: number;
  name: string;
  type: ProductType;
}

export interface SubCategory {
  id: number;
  name: string;
  category: Category;
}

export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  stock: number;
  imagePath: string | null;
  subCategory: SubCategory;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService {


  private apiUrl = '/api/products';


  constructor(private http: HttpClient) { }

  getAllProduct(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

  getProductById(id: number): Observable<Product> {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }

  createProduct(formData: FormData): Observable<any> {
    return this.http.post(`${this.apiUrl}`, formData, { withCredentials: true });
  }

  updateProduct(id: number, formData: FormData): Observable<any> {
    return this.http.put(`${this.apiUrl}/${id}`, formData, { withCredentials: true });
  }

  deleteProduct(id: number): Observable<any> {
    return this.http.delete(`${this.apiUrl}/${id}`, { withCredentials: true });
  }

  getTypes(): Observable<ProductType[]> {
    return this.http.get<ProductType[]>(`${this.apiUrl}/taxonomy/types`, { withCredentials: true });
  }

  getCategories(typeId?: number): Observable<Category[]> {
    const url = typeId
      ? `${this.apiUrl}/taxonomy/categories?typeId=${typeId}`
      : `${this.apiUrl}/taxonomy/categories`;
    return this.http.get<Category[]>(url, { withCredentials: true });
  }

  getSubCategories(categoryId?: number): Observable<SubCategory[]> {
    const url = categoryId
      ? `${this.apiUrl}/taxonomy/subcategories?categoryId=${categoryId}`
      : `${this.apiUrl}/taxonomy/subcategories`;
    return this.http.get<SubCategory[]>(url, { withCredentials: true });
  }

}
