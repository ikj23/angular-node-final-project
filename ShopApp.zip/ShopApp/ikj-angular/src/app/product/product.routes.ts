import { Routes } from '@angular/router';
import { ProductlistComponent } from './productlist/productlist.component';
import { ProductDetailComponent } from './productdetail/productdetail.component';


export const PRODUCT_ROUTES: Routes = [
    { path: '', component: ProductlistComponent },
    //   { path: 'taxonomy/types', component: ProductTypesComponent },
    //   { path: 'taxonomy/categories', component: ProductCategoriesComponent },
    //   { path: 'taxonomy/subcategories', component: ProductSubcategoriesComponent },
    { path: ':id', component: ProductDetailComponent }
];