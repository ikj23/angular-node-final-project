import { Component, OnInit } from '@angular/core';
import { Product, ProductService, ProductType, Category, SubCategory } from '../../../services/product.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productlist',
  imports: [CommonModule, FormsModule],
  templateUrl: './productlist.component.html',
  styleUrl: './productlist.component.css'
})
export class ProductlistComponent implements OnInit {
  products: Product[] = [];

  types: ProductType[] = [];
  categories: Category[] = [];
  subCategories: SubCategory[] = [];

  selectedTypeId: number | undefined = undefined;
  selectedCategoryId: number | undefined = undefined;
  selectedSubCategoryId: number | undefined = undefined;
  searchTerm = '';

  loading = false;

  currentPage = 1;
  totalPages = 0;
  totalProducts = 0;
  limit = 6;

  constructor(
    private svc: ProductService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.svc.getTypes().subscribe(res => this.types = res);
    this.svc.getCategories().subscribe(res => this.categories = res);
    this.svc.getSubCategories().subscribe(res => this.subCategories = res);
    this.loadProducts();
  }

  loadProducts(): void {
    this.loading = true;
    this.svc.getFilteredProducts(
      this.searchTerm || undefined,
      this.selectedTypeId,
      this.selectedCategoryId,
      this.selectedSubCategoryId,
      this.currentPage,
      this.limit
    ).subscribe({
      next: (res) => {
        this.products = res.products;
        this.totalPages = res.totalPages;
        this.totalProducts = res.total;
        this.loading = false;
      },
      error: () => {
        this.loading = false;
      }
    });
  }

  applyFilters(): void {
    this.currentPage = 1;
    this.loadProducts();
  }

  clearFilters(): void {
    this.selectedTypeId = undefined;
    this.selectedCategoryId = undefined;
    this.selectedSubCategoryId = undefined;
    this.searchTerm = '';
    this.currentPage = 1;
    this.loadProducts();
  }

  goToPage(page: number): void {
    if (page < 1 || page > this.totalPages) return;
    this.currentPage = page;
    this.loadProducts();
  }

  getPages(): number[] {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  goToProduct(id: number): void {
    this.router.navigate(['/products', id]);
  }

  getImageUrl(imagePath: string | null): string {
    if (!imagePath) return 'assets/default-product.png';
    return `/${imagePath}`;
  }
}