import { Component, OnInit } from '@angular/core';
import { Product, ProductService, ProductType, Category, SubCategory } from '../../../services/product.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-productlist',
  imports: [CommonModule, FormsModule],
  templateUrl: './productlist.component.html',
  styleUrl: './productlist.component.css'
})
export class ProductlistComponent implements OnInit {
  products: Product[] = [];
  allProducts: Product[] = [];

  types: ProductType[] = [];
  categories: Category[] = [];
  subCategories: SubCategory[] = [];

  selectedType = '';
  selectedCategory = '';
  selectedSubCategory = '';
  searchTerm = '';

  constructor(
    private svc: ProductService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.svc.getAllProduct().subscribe(res => {
      this.allProducts = res;
      this.products = res;
    });

    this.svc.getTypes().subscribe(res => this.types = res);
    this.svc.getCategories().subscribe(res => this.categories = res);
    this.svc.getSubCategories().subscribe(res => this.subCategories = res);
  }

  applyFilters(): void {
    this.products = this.allProducts.filter(p => {
      const matchType = this.selectedType
        ? p.subCategory?.category?.type?.name === this.selectedType
        : true;

      const matchCategory = this.selectedCategory
        ? p.subCategory?.category?.name === this.selectedCategory
        : true;

      const matchSubCategory = this.selectedSubCategory
        ? p.subCategory?.name === this.selectedSubCategory
        : true;

      const matchSearch = this.searchTerm
        ? p.name.toLowerCase().includes(this.searchTerm.toLowerCase()) ||
          p.description.toLowerCase().includes(this.searchTerm.toLowerCase())
        : true;

      return matchType && matchCategory && matchSubCategory && matchSearch;
    });
  }

  clearFilters(): void {
    this.selectedType = '';
    this.selectedCategory = '';
    this.selectedSubCategory = '';
    this.searchTerm = '';
    this.products = this.allProducts;
  }

  goToProduct(id: number): void {
    this.router.navigate(['/products', id]);
  }

  getImageUrl(imagePath: string | null): string {
    if (!imagePath) return 'assets/default-product.png';
    return `/${imagePath}`;
  }
}