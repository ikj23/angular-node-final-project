import { Component, OnInit } from '@angular/core';
import { Product, ProductService } from '../../../services/product.service';
import { CommonModule, JsonPipe } from '@angular/common';
import { Route, Router } from '@angular/router';


@Component({
  selector: 'app-productlist',
  imports: [JsonPipe, CommonModule],
  templateUrl: './productlist.component.html',
  styleUrl: './productlist.component.css'
})
export class ProductlistComponent implements OnInit {
  products: Product[] = []
  constructor(
    private svc: ProductService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadAllProduct()
    console.log("Products loaded");

  }

  loadAllProduct() {
    this.svc.getAllProduct().subscribe({
      next: (res) => {
        this.products = res

      }
    })
  }

  goToProduct(id: number) {
    this.router.navigate(['/products', id]);
  }
}
