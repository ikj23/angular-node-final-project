import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Product, ProductService } from '../../../services/product.service';
import { CartService } from '../../../services/cart.service';

@Component({
  selector: 'app-productdetail',
  imports: [CommonModule],
  templateUrl: './productdetail.component.html',
  styleUrl: './productdetail.component.css'
})
export class ProductDetailComponent implements OnInit {
  product: Product | null = null;
  quantity: number = 1;
  adding: boolean = false;
  successMessage: string = '';
  errorMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private productSvc: ProductService,
    private cartSvc: CartService
  ) { }

  ngOnInit(): void {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.productSvc.getProductById(id).subscribe({
      next: (res) => {
        this.product = res;
      },
      error: (err) => {
        console.error('Failed to fetch product', err);
      }
    });
  }

  increment() {
    if (this.product && this.quantity < this.product.stock) {
      this.quantity++;
    }
  }

  decrement() {
    if (this.quantity > 1) {
      this.quantity--;
    }
  }

  addToCart() {
    if (!this.product) return;

    this.adding = true;
    this.successMessage = '';
    this.errorMessage = '';

    this.cartSvc.addToCart(this.product.id, this.quantity).subscribe({
      next: (res) => {
        this.successMessage = res.message;
        this.adding = false;
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Failed to add to cart';
        this.adding = false;
      }
    });
  }

  goBack() {
    this.router.navigate(['/products']);
  }
}