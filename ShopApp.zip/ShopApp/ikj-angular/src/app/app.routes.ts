import { Routes } from '@angular/router';
import { RegisterComponent } from './auth/register/register.component';
import { LoginComponent } from './auth/login/login.component';
import { ForgotPasswordComponent } from './auth/forgot-password/forgot-password.component';
import { ChangePasswordComponent } from './auth/change-password/change-password.component';
import { ResetPasswordComponent } from './auth/reset-password/reset-password.component';
import { ProfileComponent } from './profile/profile.component';
import { CartComponent } from './cart/cart.component';
import { CheckoutComponent } from './checkout/checkout.component';
import { OrderDetailComponent } from './order-detail/order-detail.component';

import { authGuard } from '../guards/auth.guard';
import { adminGuard } from '../guards/admin.guard';
import { OrderHistoryComponent } from './order-history/order-history.component';

export const routes: Routes = [
    { path: 'register', component: RegisterComponent },
    { path: 'login', component: LoginComponent },
    { path: 'forgot-password', component: ForgotPasswordComponent },
    { path: 'change-password', component: ChangePasswordComponent, canActivate: [authGuard] },
    { path: 'reset-password', component: ResetPasswordComponent },

    { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
    { path: 'cart', component: CartComponent, canActivate: [authGuard] },
    { path: 'checkout', component: CheckoutComponent, canActivate: [authGuard] },
    { path: 'orders', component: OrderHistoryComponent, canActivate: [authGuard] },
    { path: 'orders/:id', component: OrderDetailComponent, canActivate: [authGuard] },

    {
        path: 'products',
        loadChildren: () =>
            import('./product/product.routes').then(m => m.PRODUCT_ROUTES)
    },

    {
        path: 'admin',
        loadChildren: () =>
            import('./admin/admin.routes').then(m => m.ADMIN_ROUTES),
        canActivate: [adminGuard]
    },

    { path: '', redirectTo: '/products', pathMatch: 'full' },
    { path: '**', redirectTo: '/products' }
];
