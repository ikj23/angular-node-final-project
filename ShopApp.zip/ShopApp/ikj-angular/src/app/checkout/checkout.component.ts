import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Cart, CartService } from '../../services/cart.service';
import { OrderService } from '../../services/order.service';


@Component({
  selector: 'app-checkout',
  imports: [CommonModule],
  templateUrl: './checkout.component.html',
  styleUrl: './checkout.component.css'
})
export class CheckoutComponent implements OnInit {
  cart: Cart | null = null;
  placing: boolean = false;
  errorMessage: string = '';
  selectedPayment: string = '';

  paymentMethods: string[] = [
    'Credit Card',
    'Debit Card',
    'Cash on Delivery',
    'Bank Transfer'
  ];

  constructor(
    private cartService: CartService,
    private orderService: OrderService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.cartService.getCart().subscribe({
      next: (res) => {
        if (res.items.length === 0) {
          this.router.navigate(['/cart']);
          return;
        }
        this.cart = res;
      },
      error: () => {
        this.errorMessage = 'Failed to load cart. Please try again.';
      }
    });
  }

  selectPayment(method: string) {
    this.selectedPayment = method;
    this.errorMessage = '';
  }

  placeOrder() {
    if (!this.selectedPayment) {
      this.errorMessage = 'Please select a payment method.';
      return;
    }

    this.placing = true;
    this.errorMessage = '';

    this.orderService.checkout(this.selectedPayment).subscribe({
      next: (res) => {
        this.router.navigate(['/orders', res.order.id]);
      },
      error: (err) => {
        this.errorMessage = err.error?.message || 'Something went wrong. Please try again.';
        this.placing = false;
      }
    });
  }

  goToCart() {
    this.router.navigate(['/cart']);
  }
}