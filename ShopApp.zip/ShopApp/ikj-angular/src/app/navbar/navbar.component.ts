import { Component, OnInit } from '@angular/core';
import { Router, RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { AuthService, User } from '../../services/auth.service';
import { CartService } from '../../services/cart.service';


@Component({
  selector: 'app-navbar',
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent implements OnInit {
  user: User | null = null;
  cartItemCount: number = 0;

  constructor(
    private authService: AuthService,
    private cartService: CartService,
    private router: Router
  ) { }

  ngOnInit(): void {
    // fetch user on app load (in case cookie is still valid)
    this.authService.fetchAndSetUser();

    // subscribe to user state changes
    this.authService.currentUser$.subscribe({
      next: (user) => {
        this.user = user;
        if (user) {
          this.loadCartCount();
        } else {
          this.cartItemCount = 0;
        }
      }
    });
  }

  loadCartCount() {
    this.cartService.getCart().subscribe({
      next: (res) => {
        this.cartItemCount = res.items.length;
      },
      error: () => {
        this.cartItemCount = 0;
      }
    });
  }

  goToCart() {
    this.router.navigate(['/cart']);
  }

  logout() {
    this.authService.logout().subscribe({
      next: () => {
        this.router.navigate(['/login']);
      }
    });
  }
}