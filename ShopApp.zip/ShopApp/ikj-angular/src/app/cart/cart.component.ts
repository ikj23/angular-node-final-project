import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Cart, CartItem, CartService } from '../../services/cart.service';

@Component({
  selector: 'app-cart',
  imports: [CommonModule],
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent implements OnInit {
  cart: Cart | null = null;
  errorMessage = '';

  constructor(
    private cartService: CartService,
    private router: Router
  ) { }

  ngOnInit() {
    this.loadCart();
  }

  loadCart() {
    this.cartService.getCart().subscribe({
      next: (res) => this.cart = res,
      error: () => this.errorMessage = 'Failed to load cart'
    });
  }

  increment(item: CartItem) {
    this.cartService.updateCartItem(item.id, item.quantity + 1).subscribe({
      next: () => this.loadCart(),
      error: (err) => this.errorMessage = err.error?.message || 'Failed to update quantity'
    });
  }

  decrement(item: CartItem) {
    if (item.quantity === 1) {
      this.remove(item);
      return;
    }
    this.cartService.updateCartItem(item.id, item.quantity - 1).subscribe({
      next: () => this.loadCart(),
      error: (err) => this.errorMessage = err.error?.message || 'Failed to update quantity'
    });
  }

  remove(item: CartItem) {
    this.cartService.removeCartItem(item.id).subscribe({
      next: () => this.loadCart(),
      error: () => this.errorMessage = 'Failed to remove item'
    });
  }

  goToProducts() {
    this.router.navigate(['/products']);
  }

  goToCheckout() {
    this.router.navigate(['/checkout']);
  }
}