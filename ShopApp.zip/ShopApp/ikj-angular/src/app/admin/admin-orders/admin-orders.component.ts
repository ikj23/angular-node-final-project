import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminOrder, AdminService } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-orders',
  imports: [CommonModule],
  templateUrl: './admin-orders.component.html',
  styleUrl: './admin-orders.component.css'
})
export class AdminOrdersComponent implements OnInit {
  orders: AdminOrder[] = [];
  selectedOrder: AdminOrder | null = null;
  errorMessage = '';

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    this.adminService.getAllOrders().subscribe({
      next: (res) => this.orders = res,
      error: () => this.errorMessage = 'Failed to load orders'
    });
  }

  viewOrder(order: AdminOrder) {
    this.selectedOrder = order;
  }

  closeDetail() {
    this.selectedOrder = null;
  }
}