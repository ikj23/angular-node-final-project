import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AdminService, Customer } from '../../../services/admin.service';

@Component({
  selector: 'app-admin-customers',
  imports: [CommonModule],
  templateUrl: './admin-customers.component.html',
  styleUrl: './admin-customers.component.css'
})
export class AdminCustomersComponent implements OnInit {
  customers: Customer[] = [];
  successMessage = '';
  errorMessage = '';

  constructor(private adminService: AdminService) { }

  ngOnInit() {
    this.loadCustomers();
  }

  loadCustomers() {
    this.adminService.getAllCustomers().subscribe({
      next: (res) => this.customers = res,
      error: () => this.errorMessage = 'Failed to load customers'
    });
  }

  toggleLock(customer: Customer) {
    const newStatus = !customer.isLocked;
    this.adminService.toggleCustomerLock(customer.id, newStatus).subscribe({
      next: () => {
        customer.isLocked = newStatus;
        this.successMessage = newStatus ? 'Customer locked' : 'Customer unlocked';
      },
      error: () => this.errorMessage = 'Failed to update customer'
    });
  }
}