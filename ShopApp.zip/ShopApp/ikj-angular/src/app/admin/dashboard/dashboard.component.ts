import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { AdminService } from '../../../services/admin.service';
import { ProductService } from '../../../services/product.service';


@Component({
  selector: 'app-dashboard',
  imports: [CommonModule],
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.css'
})
export class DashboardComponent implements OnInit {
  totalProducts: number = 0;
  totalCustomers: number = 0;
  totalOrders: number = 0;
  totalRevenue: number = 0;
  recentOrders: any[] = [];
  loading: boolean = true;

  constructor(
    private adminService: AdminService,
    private productService: ProductService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.loadDashboard();
  }

  loadDashboard() {
    // Load products count
    this.productService.getAllProduct().subscribe({
      next: (res) => this.totalProducts = res.length
    });

    // Load customers count
    this.adminService.getAllCustomers().subscribe({
      next: (res) => this.totalCustomers = res.length
    });

    // Load orders + revenue + recent orders
    this.adminService.getAllOrders().subscribe({
      next: (res) => {
        this.totalOrders = res.length;
        this.totalRevenue = res.reduce((sum, o) => sum + Number(o.totalAmount), 0);
        this.recentOrders = res;
        this.loading = false;
      }
    });
  }

  goToOrder(id: number) {
    this.router.navigate(['/admin/orders']);
  }
}