import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Category, Product, ProductService, ProductType, SubCategory } from '../../../services/product.service';

@Component({
  selector: 'app-admin-products',
  imports: [CommonModule, FormsModule],
  templateUrl: './admin-product.component.html',
  styleUrl: './admin-product.component.css'
})
export class AdminProductsComponent implements OnInit {
  products: Product[] = [];
  types: ProductType[] = [];
  categories: Category[] = [];
  subCategories: SubCategory[] = [];

  showForm = false;
  editingId: number | null = null;
  selectedFile: File | null = null;
  successMessage = '';
  errorMessage = '';

  form = {
    name: '',
    description: '',
    price: '',
    stock: '',
    typeId: '',
    categoryId: '',
    subCategoryId: ''
  };

  constructor(private productService: ProductService) { }

  ngOnInit() {
    this.loadProducts();
    this.productService.getTypes().subscribe(res => this.types = res);
  }

  loadProducts() {
    this.productService.getAllProductsAdmin().subscribe(res => this.products = res);
}

  onTypeChange() {
    this.form.categoryId = '';
    this.form.subCategoryId = '';
    this.categories = [];
    this.subCategories = [];
    if (this.form.typeId) {
      this.productService.getCategories(Number(this.form.typeId)).subscribe(res => this.categories = res);
    }
  }

  onCategoryChange() {
    this.form.subCategoryId = '';
    this.subCategories = [];
    if (this.form.categoryId) {
      this.productService.getSubCategories(Number(this.form.categoryId)).subscribe(res => this.subCategories = res);
    }
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }

  openCreate() {
    this.showForm = true;
    this.editingId = null;
    this.selectedFile = null;
    this.successMessage = '';
    this.errorMessage = '';
    this.form = { name: '', description: '', price: '', stock: '', typeId: '', categoryId: '', subCategoryId: '' };
    this.categories = [];
    this.subCategories = [];
  }

  openEdit(product: Product) {
    this.showForm = true;
    this.editingId = product.id;
    this.successMessage = '';
    this.errorMessage = '';

    const typeId = product.subCategory.category.type.id;
    const categoryId = product.subCategory.category.id;

    this.productService.getCategories(typeId).subscribe(res => {
      this.categories = res;
      this.productService.getSubCategories(categoryId).subscribe(sub => {
        this.subCategories = sub;
        this.form = {
          name: product.name,
          description: product.description,
          price: String(product.price),
          stock: String(product.stock),
          typeId: String(typeId),
          categoryId: String(categoryId),
          subCategoryId: String(product.subCategory.id)
        };
      });
    });
  }

  closeForm() {
    this.showForm = false;
    this.editingId = null;
    this.selectedFile = null;
  }

  onSubmit() {
    const formData = new FormData();
    formData.append('name', this.form.name);
    formData.append('description', this.form.description);
    formData.append('price', this.form.price);
    formData.append('stock', this.form.stock);
    formData.append('subCategoryId', this.form.subCategoryId);
    if (this.selectedFile) {
      formData.append('image', this.selectedFile);
    }

    if (this.editingId) {
      this.productService.updateProduct(this.editingId, formData).subscribe({
        next: () => {
          this.successMessage = 'Product updated successfully';
          this.loadProducts();
          this.closeForm();
        },
        error: (err) => this.errorMessage = err.error?.message || 'Failed to update product'
      });
    } else {
      this.productService.createProduct(formData).subscribe({
        next: () => {
          this.successMessage = 'Product created successfully';
          this.loadProducts();
          this.closeForm();
        },
        error: (err) => this.errorMessage = err.error?.message || 'Failed to create product'
      });
    }
  }

  deleteProduct(id: number) {
    if (!confirm('Delete this product?')) return;
    this.productService.deleteProduct(id).subscribe({
      next: () => {
        this.successMessage = 'Product deleted';
        this.loadProducts();
      },
      error: () => this.errorMessage = 'Failed to delete product'
    });
  }
}