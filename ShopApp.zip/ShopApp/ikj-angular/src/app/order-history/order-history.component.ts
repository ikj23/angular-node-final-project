import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { Order, OrderService } from '../../services/order.service';


@Component({
  selector: 'app-order-history',
  imports: [CommonModule],
  templateUrl: './order-history.component.html',
  styleUrl: './order-history.component.css'
})
export class OrderHistoryComponent implements OnInit {
  orders: Order[] = [];
  loading: boolean = true;
  errorMessage: string = '';

  constructor(
    private orderService: OrderService,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.orderService.getMyOrders().subscribe({
      next: (res) => {
        this.orders = res;
        this.loading = false;
      },
      error: () => {
        this.errorMessage = 'Failed to load orders. Please try again.';
        this.loading = false;
      }
    });
  }

  goToOrderDetail(id: number) {
    this.router.navigate(['/orders', id]);
  }

  goToProducts() {
    this.router.navigate(['/products']);
  }

  getItemCount(order: Order): number {
    return order.items.reduce((sum, item) => sum + item.quantity, 0);
  }

  getProductNames(order: Order): string {
    return order.items
      .slice(0, 2)
      .map(item => item.product.name)
      .join(', ');
  }
}