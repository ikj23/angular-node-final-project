import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-change-password',
  imports: [ReactiveFormsModule],
  templateUrl: './change-password.component.html',
  styleUrl: './change-password.component.css'
})
export class ChangePasswordComponent {
  changeForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private svc: AuthService,
    private router: Router
  ) {
    this.changeForm = this.fb.group({
      currpassword: ['', [Validators.required, Validators.minLength(6)]],
      newpassword: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    if (this.changeForm.valid) {
      this.svc.ChangePassword(this.changeForm.value).subscribe({
        next: (res) => {
          console.log('passwordChange', res.message);
          // console.log("user: " , res.user);
          this.router.navigate(['/login']); // Redirect after success
        },
        error: (err) => {
          this.errorMessage = err.error?.message || 'Something went wrong. Please try again.';
        }
      });
    }
  }

  logout() {
    this.svc.logout().subscribe({
      next: (res) => {
        console.log(res.message);
        this.router.navigate(['/login']); //redirect after logout
      },
      error: (err) => {
        console.log(err.err.message);

      }
    })
  }
}

