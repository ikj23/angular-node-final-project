import { Component } from '@angular/core';
import { AuthService } from '../../../services/auth.service';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-forgot-password',
  imports: [ReactiveFormsModule, CommonModule, RouterLink],
  templateUrl: './forgot-password.component.html',
  styleUrl: './forgot-password.component.css'
})
export class ForgotPasswordComponent {

  forgotPassword: FormGroup
  code: number = 0
  isOpen = false

  constructor(
    private svc: AuthService,
    private fb: FormBuilder
  ) {
    this.forgotPassword = this.fb.group({
      email: ["", [Validators.required, Validators.email]]
    })
  }

  onSubmit() {
    if (this.forgotPassword.valid) {
      this.svc.forgotPassword(this.forgotPassword.value).subscribe({
        next: (res) => {
          this.code = res.code
          console.log(res.message);
        }
      })
      this.isOpen = true
    }
  }






}
