import { Component } from '@angular/core';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import { Router, RouterLink } from '@angular/router';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, RouterLink],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;
  errorMessage: string = '';

  constructor(
    private fb: FormBuilder,
    private svc: AuthService,
    private router: Router
  ) {
    this.loginForm = this.fb.group({
      email: ['', [Validators.required, Validators.email]],
      password: ['', [Validators.required, Validators.minLength(6)]]
    });
  }

  onSubmit() {
    if (this.loginForm.valid) {
      this.svc.login(this.loginForm.value).subscribe({
        next: (res) => {
          console.log('Login successful', res.message);
          console.log("user: ", res.user);
          this.router.navigate(['/products']); // Redirect after success
        },
        error: (err) => {
          this.errorMessage = err.error?.message || 'Something went wrong. Please try again.';
        }
      });
    }
  }

  logout() {
    this.svc.logout().subscribe({
      next: (res) => {
        console.log(res.message);
        this.router.navigate(['/login']); //redirect after logout
      },
      error: (err) => {
        console.log(err.err.message);

      }
    })
  }

  forgot() {
    console.log("hello");
    this.router.navigate(['/forgot-password'])
  }
}

