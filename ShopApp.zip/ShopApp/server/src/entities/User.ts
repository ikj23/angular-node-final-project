import { Entity, PrimaryGeneratedColumn, Column, OneToOne, OneToMany } from 'typeorm';
import { Cart } from './Cart';
import { Order } from './Order';
import { PasswordReset } from './PasswordReset';

@Entity()
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column()
  name: string;

  @Column({ unique: true })
  email: string;

  @Column()
  password: string;

  @Column({ default: 'customer' })
  role: string;

  @Column({ default: false })
  isLocked: boolean;

  @OneToOne(() => Cart, (cart) => cart.user)
  cart: Cart;

  @OneToMany(() => Order, (order) => order.user)
  orders: Order[];

  @OneToOne(() => PasswordReset, (passwordReset) => passwordReset.user)
  passwordReset: PasswordReset;
}