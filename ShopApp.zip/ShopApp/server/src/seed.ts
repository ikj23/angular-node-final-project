import 'reflect-metadata';
import { AppDataSource } from './data-source';
import { ProductType } from './entities/ProductType';
import { Category } from './entities/Category';
import { SubCategory } from './entities/SubCategory';
import { Product } from './entities/Product';
import { User } from './entities/User';
import bcrypt from 'bcrypt';

async function seed() {
  await AppDataSource.initialize();

  const typeRepo = AppDataSource.getRepository(ProductType);
  const categoryRepo = AppDataSource.getRepository(Category);
  const subCategoryRepo = AppDataSource.getRepository(SubCategory);
  const productRepo = AppDataSource.getRepository(Product);
  const userRepo = AppDataSource.getRepository(User);

  // --- Types ---
  const electronics = typeRepo.create({ name: 'Electronics' });
  const stationery = typeRepo.create({ name: 'Stationery' });
  const furniture = typeRepo.create({ name: 'Furniture' });
  await typeRepo.save([electronics, stationery, furniture]);

  // --- Categories ---
  const peripherals = categoryRepo.create({ name: 'Computer Peripherals', type: electronics });
  const kids = categoryRepo.create({ name: 'Kids', type: stationery });
  const officeFurniture = categoryRepo.create({ name: 'Office Furniture', type: furniture });
  await categoryRepo.save([peripherals, kids, officeFurniture]);

  // --- SubCategories ---
  const keyboards = subCategoryRepo.create({ name: 'Keyboards', category: peripherals });
  const textbooks = subCategoryRepo.create({ name: 'Textbooks', category: kids });
  const desks = subCategoryRepo.create({ name: 'Desks', category: officeFurniture });
  await subCategoryRepo.save([keyboards, textbooks, desks]);

  // --- Products ---
  await productRepo.save([
    productRepo.create({
      name: 'Anker Multimedia Keyboard',
      description: 'A compact and quiet keyboard perfect for office use',
      price: 29.99,
      stock: 50,
      subCategory: keyboards
    }),
    productRepo.create({
      name: 'Mechanical Gaming Keyboard',
      description: 'RGB backlit mechanical keyboard with tactile switches',
      price: 89.99,
      stock: 30,
      subCategory: keyboards
    }),
    productRepo.create({
      name: 'Multiplication Table Book',
      description: 'A helpful table reference book for kids learning maths',
      price: 5.99,
      stock: 100,
      subCategory: textbooks
    }),
    productRepo.create({
      name: 'Science Textbook Grade 5',
      description: 'Comprehensive science textbook for grade 5 students',
      price: 12.99,
      stock: 75,
      subCategory: textbooks
    }),
    productRepo.create({
      name: 'Wooden Study Table',
      description: 'Solid wood study table with drawer storage',
      price: 199.99,
      stock: 15,
      subCategory: desks
    }),
  ]);

  // --- Admin User ---
  const hashedPassword = await bcrypt.hash('admin123', 10);
  await userRepo.save(
    userRepo.create({
      name: 'Admin',
      email: 'admin@shop.com',
      password: hashedPassword,
      role: 'admin'
    })
  );



  const hashedPassword1 = await bcrypt.hash('ikj123', 10);
  await userRepo.save(
    userRepo.create({
      name: 'IKj',
      email: 'ikj@admin.com',
      password: hashedPassword1,
      role: 'admin'
    })
  );

  console.log('Seeding complete!');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seeding failed:', err);
  process.exit(1);
});