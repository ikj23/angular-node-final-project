import { Request, Response } from 'express';
import { AppDataSource } from '../data-source';
import { User } from '../entities/User';
import { Order } from '../entities/Order';
import sessionStore from '../sessionStore';

export const getAllCustomers = async (req: Request, res: Response) => {
  try {
    const userRepo = AppDataSource.getRepository(User);

    const customers = await userRepo.find({
      where: { role: 'customer' },
      select: ['id', 'name', 'email', 'isLocked'],
      order: { id: 'DESC' }
    });

    return res.json(customers);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const toggleCustomerLock = async (req: Request, res: Response) => {
  try {
    const customerId = parseInt(req.params.id as string);
    const { isLocked } = req.body;

    if (typeof isLocked !== 'boolean') {
      return res.status(400).json({ message: 'isLocked must be true or false' });
    }

    const userRepo = AppDataSource.getRepository(User);
    const customer = await userRepo.findOne({ where: { id: customerId, role: 'customer' } });

    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }

    customer.isLocked = isLocked;
    await userRepo.save(customer);

    if (isLocked) {
      for (const [token, session] of sessionStore.entries()) {
        if (session.userId === customerId) {
          sessionStore.delete(token);
        }
      }
    }

    return res.json({
      message: isLocked ? 'Customer account locked successfully' : 'Customer account unlocked successfully',
      customer: {
        id: customer.id,
        name: customer.name,
        email: customer.email,
        isLocked: customer.isLocked
      }
    });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const getAllOrders = async (req: Request, res: Response) => {
  try {
    const orderRepo = AppDataSource.getRepository(Order);

    const orders = await orderRepo.find({
      relations: ['user', 'items', 'items.product'],
      order: { createdAt: 'DESC' }
    });

    const safeOrders = orders.map(order => ({
      id: order.id,
      totalAmount: order.totalAmount,
      paymentMethod: order.paymentMethod,
      createdAt: order.createdAt,
      customer: {
        id: order.user.id,
        name: order.user.name,
        email: order.user.email
      },
      items: order.items.map(item => ({
        id: item.id,
        quantity: item.quantity,
        priceAtPurchase: item.priceAtPurchase,
        product: {
          id: item.product.id,
          name: item.product.name
        }
      }))
    }));

    return res.json(safeOrders);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const getAdminOrderById = async (req: Request, res: Response) => {
  try {
    const orderId = parseInt(req.params.id as string);

    if (isNaN(orderId)) {
      return res.status(400).json({ message: 'Invalid order ID' });
    }

    const orderRepo = AppDataSource.getRepository(Order);

    const order = await orderRepo.findOne({
      where: { id: orderId },
      relations: [
        'user',
        'items',
        'items.product',
        'items.product.subCategory',
        'items.product.subCategory.category',
        'items.product.subCategory.category.type'
      ]
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    return res.json({
      id: order.id,
      totalAmount: order.totalAmount,
      paymentMethod: order.paymentMethod,
      createdAt: order.createdAt,
      customer: {
        id: order.user.id,
        name: order.user.name,
        email: order.user.email
      },
      items: order.items.map(item => ({
        id: item.id,
        quantity: item.quantity,
        priceAtPurchase: item.priceAtPurchase,
        product: {
          id: item.product.id,
          name: item.product.name,
          imagePath: item.product.imagePath,
          subCategory: item.product.subCategory
        }
      }))
    });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};