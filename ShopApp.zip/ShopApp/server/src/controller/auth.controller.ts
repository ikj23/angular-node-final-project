import { Request, Response } from 'express';
import bcrypt from 'bcrypt';
import jwt from 'jsonwebtoken';
import { AppDataSource } from '../data-source';
import { User } from '../entities/User';
import { Cart } from '../entities/Cart';
import sessionStore from '../sessionStore';
import { JWT_SECRET } from '../middleware/auth';
import { PasswordReset } from '../entities/PasswordReset';

export const register = async (req: Request, res: Response) => {
  try {
    const { name, email, password } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({ message: 'Name, email and password are required' });
    }

    if (password.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email address' });
    }

    const userRepo = AppDataSource.getRepository(User);
    const cartRepo = AppDataSource.getRepository(Cart);

    const existing = await userRepo.findOne({ where: { email } });
    if (existing) {
      return res.status(400).json({ message: 'An account with this email already exists' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = userRepo.create({
      name: name.trim(),
      email: email.toLowerCase().trim(),
      password: hashedPassword,
      role: 'customer'
    });

    await userRepo.save(user);

    const cart = cartRepo.create({ user });
    await cartRepo.save(cart);

    return res.status(201).json({ message: 'Account created successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const login = async (req: Request, res: Response) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ message: 'Email and password are required' });
    }

    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { email: email.toLowerCase().trim() } });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    if (user.isLocked) {
      return res.status(403).json({ message: 'Your account has been locked. Please contact support.' });
    }

    const passwordMatch = await bcrypt.compare(password, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    const token = jwt.sign(
      { userId: user.id, role: user.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    sessionStore.set(token, {
      userId: user.id,
      role: user.role,
      email: user.email
    });

    res.cookie('token', token, {
      httpOnly: true,
      secure: false,
      sameSite: 'lax',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    return res.json({
      message: 'Logged in successfully',
      user: {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role
      }
    });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const logout = async (req: Request, res: Response) => {
  const token = (req as any).token;
  sessionStore.delete(token);
  res.clearCookie('token');
  return res.json({ message: 'Logged out successfully' });
};

export const getMe = async (req: Request, res: Response) => {
  const user = (req as any).user;
  return res.json({
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role
  });
};

export const forgotPassword = async (req: Request, res: Response) => {
  try {
    const { email } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    const userRepo = AppDataSource.getRepository(User);
    const passwordResetRepo = AppDataSource.getRepository(PasswordReset);

    const user = await userRepo.findOne({
      where: { email: email.toLowerCase().trim() }
    });

    if (!user) {
      return res.status(404).json({ message: 'No account found with this email' });
    }

    const code = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60 * 1000);

    const existingReset = await passwordResetRepo.findOne({
      where: { user: { id: user.id } }
    });

    if (existingReset) {
      existingReset.code = code;
      existingReset.expiresAt = expiresAt;
      existingReset.used = false;
      await passwordResetRepo.save(existingReset);
    } else {
      const passwordReset = passwordResetRepo.create({
        user,
        code,
        expiresAt,
        used: false
      });
      await passwordResetRepo.save(passwordReset);
    }

    return res.json({
      message: 'Reset code generated',
      code
    });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const resetPassword = async (req: Request, res: Response) => {
  try {
    const { email, code, newPassword } = req.body;

    if (!email || !code || !newPassword) {
      return res.status(400).json({ message: 'Email, code and new password are required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'Password must be at least 6 characters' });
    }

    const userRepo = AppDataSource.getRepository(User);
    const passwordResetRepo = AppDataSource.getRepository(PasswordReset);

    const user = await userRepo.findOne({
      where: { email: email.toLowerCase().trim() }
    });

    if (!user) {
      return res.status(400).json({ message: 'Invalid request' });
    }

    const passwordReset = await passwordResetRepo.findOne({
      where: { user: { id: user.id } },
      relations: ['user']
    });

    if (!passwordReset) {
      return res.status(400).json({ message: 'No reset code found. Please request a new one.' });
    }

    if (passwordReset.used) {
      return res.status(400).json({ message: 'This reset code has already been used. Please request a new one.' });
    }

    if (passwordReset.code !== code) {
      return res.status(400).json({ message: 'Incorrect reset code' });
    }

    if (new Date() > passwordReset.expiresAt) {
      return res.status(400).json({ message: 'Reset code has expired. Please request a new one.' });
    }

    user.password = await bcrypt.hash(newPassword, 10);
    await userRepo.save(user);

    passwordReset.used = true;
    await passwordResetRepo.save(passwordReset);

    return res.json({ message: 'Password reset successfully. You can now log in.' });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const changePassword = async (req: Request, res: Response) => {
  try {
    const { currentPassword, newPassword } = req.body;
    const user = (req as any).user;

    if (!currentPassword || !newPassword) {
      return res.status(400).json({ message: 'Current and new password are required' });
    }

    if (newPassword.length < 6) {
      return res.status(400).json({ message: 'New password must be at least 6 characters' });
    }

    const passwordMatch = await bcrypt.compare(currentPassword, user.password);
    if (!passwordMatch) {
      return res.status(401).json({ message: 'Current password is incorrect' });
    }

    const userRepo = AppDataSource.getRepository(User);
    user.password = await bcrypt.hash(newPassword, 10);
    await userRepo.save(user);

    return res.json({ message: 'Password changed successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const updateProfile = async (req: Request, res: Response) => {
  try {
    const { name, email } = req.body;
    const user = (req as any).user;

    if (!name || !email) {
      return res.status(400).json({ message: 'Name and email are required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ message: 'Invalid email address' });
    }

    const userRepo = AppDataSource.getRepository(User);

    const emailTaken = await userRepo.findOne({ where: { email: email.toLowerCase().trim() } });
    if (emailTaken && emailTaken.id !== user.id) {
      return res.status(400).json({ message: 'This email is already in use' });
    }

    user.name = name.trim();
    user.email = email.toLowerCase().trim();
    await userRepo.save(user);

    return res.json({
      message: 'Profile updated successfully',
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};