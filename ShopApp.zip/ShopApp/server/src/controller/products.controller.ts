import { Request, Response } from 'express';
import { AppDataSource } from '../data-source';
import { Product } from '../entities/Product';
import { ProductType } from '../entities/ProductType';
import { Category } from '../entities/Category';
import { SubCategory } from '../entities/SubCategory';
import fs from 'fs';
import path from 'path';

export const getAllProducts = async (req: Request, res: Response) => {
  try {
    const { search, typeId, categoryId, subCategoryId } = req.query as Record<string, string>;
    const repo = AppDataSource.getRepository(Product);

    const query = repo.createQueryBuilder('product')
      .leftJoinAndSelect('product.subCategory', 'subCategory')
      .leftJoinAndSelect('subCategory.category', 'category')
      .leftJoinAndSelect('category.type', 'type')
      .orderBy('product.id', 'DESC');

    if (search && search.trim() !== '') {
      query.andWhere(
        'LOWER(product.name) LIKE :search OR LOWER(product.description) LIKE :search',
        { search: `%${search.toLowerCase()}%` }
      );
    }

    if (typeId) {
      query.andWhere('type.id = :typeId', { typeId: parseInt(typeId) });
    }

    if (categoryId) {
      query.andWhere('category.id = :categoryId', { categoryId: parseInt(categoryId) });
    }

    if (subCategoryId) {
      query.andWhere('subCategory.id = :subCategoryId', { subCategoryId: parseInt(subCategoryId) });
    }

    const products = await query.getMany();
    return res.json(products);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const getProductById = async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id as string);

    if (isNaN(id)) {
      return res.status(400).json({ message: 'Invalid product ID' });
    }

    const repo = AppDataSource.getRepository(Product);

    const product = await repo.findOne({
      where: { id },
      relations: ['subCategory', 'subCategory.category', 'subCategory.category.type']
    });

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    return res.json(product);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const getAllTypes = async (req: Request, res: Response) => {
  try {
    const repo = AppDataSource.getRepository(ProductType);
    const types = await repo.find();
    return res.json(types);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong.' });
  }
};

export const getAllCategories = async (req: Request, res: Response) => {
  try {
    const { typeId } = req.query as Record<string, string>;
    const repo = AppDataSource.getRepository(Category);

    const where = typeId ? { type: { id: parseInt(typeId) } } : {};
    const categories = await repo.find({ where, relations: ['type'] });

    return res.json(categories);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong.' });
  }
};

export const getAllSubCategories = async (req: Request, res: Response) => {
  try {
    const { categoryId } = req.query as Record<string, string>;
    const repo = AppDataSource.getRepository(SubCategory);

    const where = categoryId ? { category: { id: parseInt(categoryId) } } : {};
    const subcategories = await repo.find({ where, relations: ['category'] });

    return res.json(subcategories);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong.' });
  }
};

export const createProduct = async (req: Request, res: Response) => {
  try {
    const { name, description, price, stock, subCategoryId } = req.body;

    if (!name || !description || !price || !subCategoryId) {
      return res.status(400).json({ message: 'Name, description, price and subcategory are required' });
    }

    if (isNaN(parseFloat(price)) || parseFloat(price) < 0) {
      return res.status(400).json({ message: 'Price must be a valid positive number' });
    }

    if (isNaN(parseInt(stock)) || parseInt(stock) < 0) {
      return res.status(400).json({ message: 'Stock must be a valid non-negative number' });
    }

    const subCategoryRepo = AppDataSource.getRepository(SubCategory);
    const subCategory = await subCategoryRepo.findOne({ where: { id: parseInt(subCategoryId) } });

    if (!subCategory) {
      return res.status(404).json({ message: 'SubCategory not found' });
    }

    const productRepo = AppDataSource.getRepository(Product);
    const imagePath = req.file ? `ProductImages/${req.file.filename}` : null;

    const product = productRepo.create({
      name: name.trim(),
      description: description.trim(),
      price: parseFloat(price),
      stock: parseInt(stock),
      imagePath,
      subCategory
    });

    await productRepo.save(product);

    return res.status(201).json({ message: 'Product created successfully', product });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const updateProduct = async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id as string);
    const { name, description, price, stock, subCategoryId } = req.body;

    const productRepo = AppDataSource.getRepository(Product);
    const product = await productRepo.findOne({
      where: { id },
      relations: ['subCategory']
    });

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    if (name) product.name = name.trim();
    if (description) product.description = description.trim();
    if (price) product.price = parseFloat(price);
    if (stock !== undefined) product.stock = parseInt(stock);

    if (subCategoryId) {
      const subCategoryRepo = AppDataSource.getRepository(SubCategory);
      const subCategory = await subCategoryRepo.findOne({ where: { id: parseInt(subCategoryId) } });
      if (!subCategory) {
        return res.status(404).json({ message: 'SubCategory not found' });
      }
      product.subCategory = subCategory;
    }

    if (req.file) {
      if (product.imagePath) {
        const oldImagePath = path.join(__dirname, '..', '..', product.imagePath);
        if (fs.existsSync(oldImagePath)) {
          fs.unlinkSync(oldImagePath);
        }
      }
      product.imagePath = `ProductImages/${req.file.filename}`;
    }

    await productRepo.save(product);

    return res.json({ message: 'Product updated successfully', product });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const deleteProduct = async (req: Request, res: Response) => {
  try {
    const id = parseInt(req.params.id as string);

    const productRepo = AppDataSource.getRepository(Product);
    const product = await productRepo.findOne({ where: { id } });

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    if (product.imagePath) {
      const imagePath = path.join(__dirname, '..', '..', product.imagePath);
      if (fs.existsSync(imagePath)) {
        fs.unlinkSync(imagePath);
      }
    }

    await productRepo.remove(product);

    return res.json({ message: 'Product deleted successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};