import { Request, Response } from 'express';
import { AppDataSource } from '../data-source';
import { Cart } from '../entities/Cart';
import { CartItem } from '../entities/CartItem';
import { Product } from '../entities/Product';

const getCartForUser = async (userId: number): Promise<Cart | null> => {
  const cartRepo = AppDataSource.getRepository(Cart);
  const cart = await cartRepo
    .createQueryBuilder('cart')
    .leftJoinAndSelect('cart.user', 'user')
    .leftJoinAndSelect('cart.items', 'items')
    .leftJoinAndSelect('items.product', 'product')
    .leftJoinAndSelect('product.subCategory', 'subCategory')
    .leftJoinAndSelect('subCategory.category', 'category')
    .leftJoinAndSelect('category.type', 'type')
    .where('user.id = :userId', { userId })
    .getOne();
  return cart;
};

export const getCart = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;

    const cart = await getCartForUser(user.id);

    if (!cart) {
      return res.json({ items: [], total: 0 });
    }

    const total = cart.items.reduce((sum, item) => {
      return sum + (Number(item.product.price) * item.quantity);
    }, 0);

    return res.json({
      cartId: cart.id,
      items: cart.items,
      total: Math.round(total * 100) / 100
    });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const addToCart = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { productId, quantity = 1 } = req.body;

    if (!productId) {
      return res.status(400).json({ message: 'Product ID is required' });
    }

    const qty = parseInt(quantity as string);
    if (isNaN(qty) || qty < 1) {
      return res.status(400).json({ message: 'Quantity must be at least 1' });
    }

    const productRepo = AppDataSource.getRepository(Product);
    const product = await productRepo.findOne({ where: { id: parseInt(productId as string) } });

    if (!product) {
      return res.status(404).json({ message: 'Product not found' });
    }

    if (product.stock < qty) {
      return res.status(400).json({ message: `Only ${product.stock} units available in stock` });
    }

    const cartRepo = AppDataSource.getRepository(Cart);
    const cartItemRepo = AppDataSource.getRepository(CartItem);

    let cart = await cartRepo
      .createQueryBuilder('cart')
      .leftJoinAndSelect('cart.user', 'user')
      .leftJoinAndSelect('cart.items', 'items')
      .leftJoinAndSelect('items.product', 'product')
      .where('user.id = :userId', { userId: user.id })
      .getOne();

    if (!cart) {
      cart = cartRepo.create({ user });
      await cartRepo.save(cart);
      cart.items = [];
    }

    const existingItem = cart.items.find(
      item => item.product.id === parseInt(productId as string)
    );

    if (existingItem) {
      const newQty = existingItem.quantity + qty;
      if (product.stock < newQty) {
        return res.status(400).json({
          message: `Cannot add ${qty} more. Only ${product.stock} units available and you already have ${existingItem.quantity} in your cart.`
        });
      }
      existingItem.quantity = newQty;
      await cartItemRepo.save(existingItem);
    } else {
      const newItem = cartItemRepo.create({ cart, product, quantity: qty });
      await cartItemRepo.save(newItem);
    }

    return res.json({ message: 'Item added to cart successfully' });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const updateCartItem = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const itemId = parseInt(req.params.itemId as string);
    const { quantity } = req.body;

    const qty = parseInt(quantity as string);
    if (isNaN(qty) || qty < 1) {
      return res.status(400).json({ message: 'Quantity must be at least 1' });
    }

    const cartItemRepo = AppDataSource.getRepository(CartItem);

    const item = await cartItemRepo
      .createQueryBuilder('item')
      .leftJoinAndSelect('item.cart', 'cart')
      .leftJoinAndSelect('cart.user', 'user')
      .leftJoinAndSelect('item.product', 'product')
      .where('item.id = :itemId', { itemId })
      .getOne();

    if (!item) {
      return res.status(404).json({ message: 'Cart item not found' });
    }

    if (item.cart.user.id !== user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    if (item.product.stock < qty) {
      return res.status(400).json({
        message: `Only ${item.product.stock} units available in stock`
      });
    }

    item.quantity = qty;
    await cartItemRepo.save(item);

    return res.json({ message: 'Cart item updated successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const removeCartItem = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const itemId = parseInt(req.params.itemId as string);

    const cartItemRepo = AppDataSource.getRepository(CartItem);

    const item = await cartItemRepo
      .createQueryBuilder('item')
      .leftJoinAndSelect('item.cart', 'cart')
      .leftJoinAndSelect('cart.user', 'user')
      .where('item.id = :itemId', { itemId })
      .getOne();

    if (!item) {
      return res.status(404).json({ message: 'Cart item not found' });
    }

    if (item.cart.user.id !== user.id) {
      return res.status(403).json({ message: 'Not authorized' });
    }

    await cartItemRepo.remove(item);

    return res.json({ message: 'Item removed from cart successfully' });
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};