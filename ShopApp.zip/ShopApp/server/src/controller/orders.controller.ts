import { Request, Response } from 'express';
import { AppDataSource } from '../data-source';
import { Order } from '../entities/Order';
import { OrderItem } from '../entities/OrderItem';
import { Cart } from '../entities/Cart';
import { CartItem } from '../entities/CartItem';
import { Product } from '../entities/Product';

export const checkout = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const { paymentMethod } = req.body;

    const validPaymentMethods = ['Credit Card', 'Debit Card', 'Cash on Delivery', 'Bank Transfer'];

    if (!paymentMethod || !validPaymentMethods.includes(paymentMethod)) {
      return res.status(400).json({
        message: 'Please select a valid payment method',
        validMethods: validPaymentMethods
      });
    }

    const cartRepo = AppDataSource.getRepository(Cart);
    const cart = await cartRepo
      .createQueryBuilder('cart')
      .leftJoinAndSelect('cart.user', 'user')
      .leftJoinAndSelect('cart.items', 'items')
      .leftJoinAndSelect('items.product', 'product')
      .where('user.id = :userId', { userId: user.id })
      .getOne();

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({ message: 'Your cart is empty' });
    }

    for (const item of cart.items) {
      if (item.product.stock < item.quantity) {
        return res.status(400).json({
          message: `"${item.product.name}" only has ${item.product.stock} units in stock but you have ${item.quantity} in your cart`
        });
      }
    }

    const totalAmount = cart.items.reduce((sum, item) => {
      return sum + (Number(item.product.price) * item.quantity);
    }, 0);

    const orderRepo = AppDataSource.getRepository(Order);
    const orderItemRepo = AppDataSource.getRepository(OrderItem);
    const cartItemRepo = AppDataSource.getRepository(CartItem);
    const productRepo = AppDataSource.getRepository(Product);

    const order = orderRepo.create({
      user,
      paymentMethod,
      totalAmount: Math.round(totalAmount * 100) / 100
    });

    await orderRepo.save(order);
                                         
    for (const item of cart.items) {
      const orderItem = orderItemRepo.create({
        order,
        product: item.product,
        quantity: item.quantity,
        priceAtPurchase: Number(item.product.price)
      });
      await orderItemRepo.save(orderItem);
      
      item.product.stock = item.product.stock - item.quantity;
      await productRepo.save(item.product);
    }

    await cartItemRepo.remove(cart.items);

    return res.status(201).json({
      message: 'Order placed successfully',
      order: {
        id: order.id,
        totalAmount: order.totalAmount,
        paymentMethod: order.paymentMethod,
        createdAt: order.createdAt
      }
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const getMyOrders = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;

    const orderRepo = AppDataSource.getRepository(Order);

    const orders = await orderRepo.find({
      where: { user: { id: user.id } },
      relations: ['items', 'items.product'],
      order: { createdAt: 'DESC' }
    });

    return res.json(orders);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};

export const getOrderById = async (req: Request, res: Response) => {
  try {
    const user = (req as any).user;
    const orderId = parseInt(req.params.id as string);

    if (isNaN(orderId)) {
      return res.status(400).json({ message: 'Invalid order ID' });
    }

    const orderRepo = AppDataSource.getRepository(Order);

    const order = await orderRepo.findOne({
      where: { id: orderId },
      relations: [
        'user',
        'items',
        'items.product',
        'items.product.subCategory',
        'items.product.subCategory.category',
        'items.product.subCategory.category.type'
      ]
    });

    if (!order) {
      return res.status(404).json({ message: 'Order not found' });
    }

    if (order.user.id !== user.id) {
      return res.status(403).json({ message: 'Not authorized to view this order' });
    }

    return res.json(order);
  } catch (err) {
    return res.status(500).json({ message: 'Something went wrong. Please try again.' });
  }
};