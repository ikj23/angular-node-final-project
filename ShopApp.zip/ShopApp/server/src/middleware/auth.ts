import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import sessionStore from '../sessionStore';
import { AppDataSource } from '../data-source';
import { User } from '../entities/User';

const JWT_SECRET = 'your_super_secret_key_change_this';

export const authenticate = async (req: Request, res: Response, next: NextFunction) => {
  try {
    const token = req.cookies?.token;

    if (!token) {
      return res.status(401).json({ message: 'Not logged in' });
    }

    const session = sessionStore.get(token);
    if (!session) {
      res.clearCookie('token');
      return res.status(401).json({ message: 'Session expired. Please log in again.' });
    }

    const userRepo = AppDataSource.getRepository(User);
    const user = await userRepo.findOne({ where: { id: session.userId } });

    if (!user) {
      sessionStore.delete(token);
      res.clearCookie('token');
      return res.status(401).json({ message: 'User not found' });
    }

    if (user.isLocked) {
      sessionStore.delete(token);
      res.clearCookie('token');
      return res.status(403).json({ message: 'Your account has been locked. Please contact support.' });
    }

    (req as any).user = user;
    (req as any).token = token;
    next();
  } catch (err) {
    return res.status(401).json({ message: 'Invalid token' });
  }
};

export const requireCustomer = (req: Request, res: Response, next: NextFunction) => {
  const user = (req as any).user;
  if (!user || (user.role !== 'customer' && user.role !== 'admin')) {
    return res.status(403).json({ message: 'Customer access required' });
  }
  next();
};

export const requireAdmin = (req: Request, res: Response, next: NextFunction) => {
  const user = (req as any).user;
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ message: 'Admin access required' });
  }
  next();
};

export { JWT_SECRET };