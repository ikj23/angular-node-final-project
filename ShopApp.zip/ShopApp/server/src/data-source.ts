import 'reflect-metadata';
import { DataSource } from 'typeorm';

export const AppDataSource = new DataSource({
  type: 'better-sqlite3',
  database: 'ecommerce.db',
  synchronize: true,
  logging: false,
  entities: ['src/entities/*.ts'],
});