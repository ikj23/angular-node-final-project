import { Router } from 'express';
import {
  getAllCustomers,
  toggleCustomerLock,
  getAllOrders,
  getAdminOrderById
} from '../controller/admin.controller';
import { authenticate, requireAdmin } from '../middleware/auth';

const router = Router();

router.get('/customers', authenticate, requireAdmin, getAllCustomers);
router.put('/customers/:id/lock', authenticate, requireAdmin, toggleCustomerLock);
router.get('/orders', authenticate, requireAdmin, getAllOrders);
router.get('/orders/:id', authenticate, requireAdmin, getAdminOrderById);

export default router;