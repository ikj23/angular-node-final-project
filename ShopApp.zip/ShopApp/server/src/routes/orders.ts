import { Router } from 'express';
import { checkout, getMyOrders, getOrderById } from '../controller/orders.controller';
import { authenticate, requireCustomer } from '../middleware/auth';

const router = Router();

router.post('/checkout', authenticate, requireCustomer, checkout);
router.get('/', authenticate, requireCustomer, getMyOrders);
router.get('/:id', authenticate, requireCustomer, getOrderById);

export default router;