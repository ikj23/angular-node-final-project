import { Router } from 'express';
import {
  getAllProducts,
  getProductById,
  getAllTypes,
  getAllCategories,
  getAllSubCategories,
  createProduct,
  updateProduct,
  deleteProduct
} from '../controller/products.controller';
import { authenticate, requireAdmin } from '../middleware/auth';
import upload from '../upload';

const router = Router();

router.get('/taxonomy/types', getAllTypes);
router.get('/taxonomy/categories', getAllCategories);
router.get('/taxonomy/subcategories', getAllSubCategories);

router.get('/', getAllProducts);
router.get('/:id', getProductById);

router.post('/', authenticate, requireAdmin, createProduct);
router.put('/:id', authenticate, requireAdmin, updateProduct);
router.delete('/:id', authenticate, requireAdmin, deleteProduct);

export default router;