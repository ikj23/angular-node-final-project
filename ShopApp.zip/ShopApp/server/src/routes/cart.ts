import { Router } from 'express';
import { getCart, addToCart, updateCartItem, removeCartItem } from '../controller/cart.controller';
import { authenticate, requireCustomer } from '../middleware/auth';

const router = Router();

router.get('/', authenticate, requireCustomer, getCart);
router.post('/items', authenticate, requireCustomer, addToCart);
router.put('/items/:itemId', authenticate, requireCustomer, updateCartItem);
router.delete('/items/:itemId', authenticate, requireCustomer, removeCartItem);

export default router;